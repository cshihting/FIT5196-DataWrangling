from IPython.core.display import HTML
css = open('style/style-table.css').read() + open('style/style-notebook.css').read()
HTML('<style>{}</style>'.format(css))
<div style=" color:black; text-shadow: 1px 1px brown; font-size:2em;  background:url(style/images/Lucerne3.jpg)">,
    <h1 align="center">Scientific Python
    <img src="style/images/kundalini_pythons_gold_outline.png" style="height:360px; align:center; " ></h1>
    </div>